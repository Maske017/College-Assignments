/* Name: Marin Aske
Course: CNT 4714 – Summer 2025 – Project Four
Assignment title: A Three-Tier Distributed Web-Based Application
Date: July 31st, 2025
*/

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

public class AccountantServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Check session first
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userType") == null) {
            System.out.println("Invalid session - redirecting to login");
            response.sendRedirect(request.getContextPath() + "/authenticate.html");
            return;
        }
        // DEBUG OUTPUT
        System.out.println("Active session for: " + session.getAttribute("username") + 
        " | Type: " + session.getAttribute("userType"));
        
        String reportType = request.getParameter("report");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String dbUrl = "jdbc:mysql://localhost:3306/project4?allowPublicKeyRetrieval=true&useSSL=false";
            String dbUser = "systemapp";
            String dbPass = "systemapp123";
            
            out.println("<html><body style='background-color:black; color:white; font-family:Arial;'>");
            out.println("<div style='width:80%; margin:0 auto;'>");
            
            try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass)) {
                switch (reportType) {
                    case "total_parts_weight":
                        try (Statement stmt = conn.createStatement()) {
                            ResultSet rs = stmt.executeQuery("SELECT SUM(weight) AS total FROM parts");
                            rs.next();
                            out.println("<h3 style='color:#6B8E23'>Total Weight of All Parts: " 
                                + rs.getDouble("total") + "</h3>");
                        }
                        break;
                        
                    case "max_supplier_status":
                        try (Statement stmt = conn.createStatement()) {
                            ResultSet rs = stmt.executeQuery("SELECT MAX(status) AS max_status FROM suppliers");
                            rs.next();
                            out.println("<h3 style='color:#6B8E23'>Maximum Supplier Status: " 
                                + rs.getInt("max_status") + "</h3>");
                        }
                        break;
                        
                    case "total_shipments":
                        try (Statement stmt = conn.createStatement()) {
                            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS total FROM shipments");
                            rs.next();
                            out.println("<h3 style='color:#6B8E23'>Total Shipments: " 
                                + rs.getInt("total") + "</h3>");
                        }
                        break;
                }
                
                out.println("<a href='accountantHome.jsp' style='color:#4B9CD3'>Back to Reports</a>");
            }
            
            out.println("</div></body></html>");
        } catch (Exception e) {
            out.println("<h3 style='color:#FF6347'>Error: " + e.getMessage() + "</h3>");
            e.printStackTrace(out);
        }
    }
}