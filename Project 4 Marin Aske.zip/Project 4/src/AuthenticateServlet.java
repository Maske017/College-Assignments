/* Name: Marin Aske
Course: CNT 4714 – Summer 2025 – Project Four
Assignment title: A Three-Tier Distributed Web-Based Application
Date: July 31st, 2025
*/

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

public class AuthenticateServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        System.out.println("\n=== AUTH ATTEMPT ===");
        System.out.println("Username: " + username);
        System.out.println("Password: " + password);
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/credentialsDB?allowPublicKeyRetrieval=true&useSSL=false",
                "systemapp",
                "systemapp123")) {
                
                String sql = "SELECT user_type FROM usercredentials WHERE BINARY login_username=? AND BINARY login_password=?";
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, username);
                    stmt.setString(2, password);
                    
                    System.out.println("Executing: " + stmt.toString());
                    
                    try (ResultSet rs = stmt.executeQuery()) {
                        if (rs.next()) {
                            String userType = rs.getString("user_type");
                            HttpSession session = request.getSession(true);
                            session.setAttribute("userType", userType);
                            session.setAttribute("username", username);
                            session.setMaxInactiveInterval(30 * 60); // 30 minutes
                            
                            System.out.println("Login SUCCESS - Redirecting to: " + userType.toLowerCase() + "Home.jsp");
                            response.sendRedirect(userType.toLowerCase() + "Home.jsp");
                        } else {
                            System.out.println("Login FAIL - Invalid credentials");
                            response.sendRedirect("errorpage.html");
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("AUTH ERROR: " + e.getMessage());
            response.sendRedirect("errorpage.html");
        }
    }
}