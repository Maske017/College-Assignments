/* Name: Marin Aske
Course: CNT 4714 – Summer 2025 – Project Four
Assignment title: A Three-Tier Distributed Web-Based Application
Date: July 31st, 2025
*/

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

public class ClientServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Debug session first
        HttpSession session = request.getSession(false);
        System.out.println("=== DEBUG ===");
        System.out.println("Session ID: " + (session != null ? session.getId() : "NULL"));
        System.out.println("UserType in session: " + (session != null ? session.getAttribute("userType") : "NULL"));
    
        if (session == null || session.getAttribute("userType") == null) {
            System.out.println("INVALID SESSION - Redirecting to login");
            response.sendRedirect("authenticate.html");
            return;
        }

        String sqlCommand = request.getParameter("sqlCommand");
        StringBuilder result = new StringBuilder();
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String dbUrl = "jdbc:mysql://localhost:3306/project4?allowPublicKeyRetrieval=true&useSSL=false";
            String dbUser = "client";
            String dbPass = "client";
            
            try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass)) {
                if (sqlCommand.trim().toUpperCase().startsWith("SELECT")) {
                    try (Statement stmt = conn.createStatement();
                         ResultSet rs = stmt.executeQuery(sqlCommand)) {
                        
                        ResultSetMetaData meta = rs.getMetaData();
                        int colCount = meta.getColumnCount();
                        
                        result.append("<table border='1' style='color:white; width:100%;'>");
                        result.append("<tr>");
                        for (int i = 1; i <= colCount; i++) {
                            result.append("<th>").append(meta.getColumnName(i)).append("</th>");
                        }
                        result.append("</tr>");
                        
                        while (rs.next()) {
                            result.append("<tr>");
                            for (int i = 1; i <= colCount; i++) {
                                result.append("<td>").append(rs.getString(i)).append("</td>");
                            }
                            result.append("</tr>");
                        }
                        result.append("</table>");
                    }
                } else {
                    // Clients can only run SELECT queries
                    result.append("<p style='color:#FF6347'>Error: Client users can only execute SELECT queries</p>");
                }
            }
        } catch (SQLException e) {
            result.append("<p style='color:#FF6347'>Error executing SQL: ")
                  .append(e.getMessage()).append("</p>");
        } catch (Exception e) {
            result.append("<p style='color:#FF6347'>System error: ")
                  .append(e.getMessage()).append("</p>");
        }
        
        request.setAttribute("result", result.toString());
        request.getRequestDispatcher("clientHome.jsp").forward(request, response);
    }
}