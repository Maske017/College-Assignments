/* Name: Marin Aske
Course: CNT 4714 – Summer 2025 – Project Four
Assignment title: A Three-Tier Distributed Web-Based Application
Date: July 31st, 2025
*/

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

public class DataEntryServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userType") == null) {
            response.sendRedirect(request.getContextPath() + "/authenticate.html");
            return;
        }

        String formType = request.getParameter("formType");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String dbUrl = "jdbc:mysql://localhost:3306/project4?allowPublicKeyRetrieval=true&useSSL=false";
            String dbUser = "dataentry";
            String dbPass = "dataentry";
            
            try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass)) {
                StringBuilder result = new StringBuilder();
                
                if ("supplier".equals(formType)) {
                    // handle supplier form
                    String snum = request.getParameter("snum");
                    String sname = request.getParameter("sname");
                    int status = Integer.parseInt(request.getParameter("status"));
                    String city = request.getParameter("city");
                    
                    String sql = "INSERT INTO suppliers (snum, sname, status, city) VALUES (?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setString(1, snum);
                        stmt.setString(2, sname);
                        stmt.setInt(3, status);
                        stmt.setString(4, city);
                        
                        int rows = stmt.executeUpdate();
                        result.append("<p style='color:#00FF00'>Added ").append(rows)
                              .append(" supplier record: (").append(snum).append(", ")
                              .append(sname).append(", ").append(status).append(", ")
                              .append(city).append(")</p>");
                    }
                } 
                else if ("part".equals(formType)) {
                    // handle part form
                    String pnum = request.getParameter("pnum");
                    String pname = request.getParameter("pname");
                    String color = request.getParameter("color");
                    int weight = Integer.parseInt(request.getParameter("weight"));
                    String city = request.getParameter("city");
                    
                    String sql = "INSERT INTO parts (pnum, pname, color, weight, city) VALUES (?, ?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setString(1, pnum);
                        stmt.setString(2, pname);
                        stmt.setString(3, color);
                        stmt.setInt(4, weight);
                        stmt.setString(5, city);
                        
                        int rows = stmt.executeUpdate();
                        result.append("<p style='color:#00FF00'>Added ").append(rows)
                              .append(" part record: (").append(pnum).append(", ")
                              .append(pname).append(", ").append(color).append(", ")
                              .append(weight).append(", ").append(city).append(")</p>");
                    }
                }
                else if ("job".equals(formType)) {
                    // handle job form
                    String jnum = request.getParameter("jnum");
                    String jname = request.getParameter("jname");
                    int numworkers = Integer.parseInt(request.getParameter("numworkers"));
                    String city = request.getParameter("city");
                    
                    String sql = "INSERT INTO jobs (jnum, jname, numworkers, city) VALUES (?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setString(1, jnum);
                        stmt.setString(2, jname);
                        stmt.setInt(3, numworkers);
                        stmt.setString(4, city);
                        
                        int rows = stmt.executeUpdate();
                        result.append("<p style='color:#00FF00'>Added ").append(rows)
                              .append(" job record: (").append(jnum).append(", ")
                              .append(jname).append(", ").append(numworkers).append(", ")
                              .append(city).append(")</p>");
                    }
                }
                else if ("shipment".equals(formType)) {
                    // handle shipment form
                    String snum = request.getParameter("snum");
                    String pnum = request.getParameter("pnum");
                    String jnum = request.getParameter("jnum");
                    int quantity = Integer.parseInt(request.getParameter("quantity"));
                    
                    String sql = "INSERT INTO shipments (snum, pnum, jnum, quantity) VALUES (?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setString(1, snum);
                        stmt.setString(2, pnum);
                        stmt.setString(3, jnum);
                        stmt.setInt(4, quantity);
                        
                        int rows = stmt.executeUpdate();
                        result.append("<p style='color:#00FF00'>Added ").append(rows)
                              .append(" shipment record: (").append(snum).append(", ")
                              .append(pnum).append(", ").append(jnum).append(", ")
                              .append(quantity).append(")</p>");
                        
                        // business logic: update supplier status if quantity >= 100
                        if (quantity >= 100) {
                            try (Statement updateStmt = conn.createStatement()) {
                                updateStmt.executeUpdate(
                                    "UPDATE suppliers SET status = status + 5 " +
                                    "WHERE snum IN (SELECT DISTINCT snum FROM shipments WHERE quantity >= 100)"
                                );
                                result.append("<p style='color:#FFA500'>Business logic triggered: Updated supplier statuses</p>");
                            }
                        }
                    }
                }
                
                request.setAttribute("result", result.toString());
                request.getRequestDispatcher("dataEntryHome.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            String errorMsg = "<p style='color:#FF0000'>Error: " + e.getMessage() + "</p>";
            request.setAttribute("result", errorMsg);
            request.getRequestDispatcher("dataEntryHome.jsp").forward(request, response);
        } catch (Exception e) {
            String errorMsg = "<p style='color:#FF0000'>System error: " + e.getMessage() + "</p>";
            request.setAttribute("result", errorMsg);
            request.getRequestDispatcher("dataEntryHome.jsp").forward(request, response);
        }
    }
}