/* Name: Marin Aske
Course: CNT 4714 – Summer 2025 – Project Four
Assignment title: A Three-Tier Distributed Web-Based Application
Date: July 31st, 2025
*/

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;

public class RootServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // debug logging
        System.out.println("\n=== ROOT SERVLET ENTERED ===");
        System.out.println("Time: " + new Date());
        
        // session validation
        HttpSession session = request.getSession(false);
        System.out.println("Session ID: " + (session != null ? session.getId() : "NULL"));
        System.out.println("UserType in session: " + (session != null ? session.getAttribute("userType") : "NULL"));
        System.out.println("Session creation time: " + (session != null ? new Date(session.getCreationTime()) : "null"));
        System.out.println("Session last accessed: " + (session != null ? new Date(session.getLastAccessedTime()) : "null"));
        
        if (session == null || !"root".equals(session.getAttribute("userType"))) {
            System.out.println("FAIL: No valid session found");
            response.sendRedirect(request.getContextPath() + "/authenticate.html");
            return;
        }
        
        System.out.println("SUCCESS: Valid session for userType: root");
        
        // process SQL command
        String sqlCommand = request.getParameter("sqlCommand");
        System.out.println("Processing SQL: " + sqlCommand);
        
        StringBuilder result = new StringBuilder();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/project4?allowPublicKeyRetrieval=true&useSSL=false&serverTimezone=UTC",
                "root",
                "Stargazer!76")) {
                
                if (sqlCommand != null && sqlCommand.trim().toUpperCase().startsWith("SELECT")) {
                    // handle queries
                    try (Statement stmt = conn.createStatement();
                         ResultSet rs = stmt.executeQuery(sqlCommand)) {
                        
                        ResultSetMetaData meta = rs.getMetaData();
                        int colCount = meta.getColumnCount();
                        
                        // build HTML table
                        result.append("<table border='1' style='color:white; width:100%;'>");
                        
                        // header row
                        result.append("<tr>");
                        for (int i = 1; i <= colCount; i++) {
                            result.append("<th>").append(meta.getColumnName(i)).append("</th>");
                        }
                        result.append("</tr>");
                        
                        // data rows
                        while (rs.next()) {
                            result.append("<tr>");
                            for (int i = 1; i <= colCount; i++) {
                                result.append("<td>").append(rs.getString(i)).append("</td>");
                            }
                            result.append("</tr>");
                        }
                        result.append("</table>");
                    }
                } else if (sqlCommand != null && !sqlCommand.trim().isEmpty()) {
                    // handle updates
                    try (Statement stmt = conn.createStatement()) {
                        int rows = stmt.executeUpdate(sqlCommand);
                        result.append("<p style='color:#00FF00'>Command executed successfully. ")
                              .append(rows).append(" row(s) affected.</p>");
                        
                        // business logic
                        if (sqlCommand.toUpperCase().contains("SHIPMENTS") && 
                            sqlCommand.toUpperCase().contains("QUANTITY")) {
                            try (Statement updateStmt = conn.createStatement()) {
                                updateStmt.executeUpdate(
                                    "UPDATE suppliers SET status = status + 5 " +
                                    "WHERE snum IN (SELECT DISTINCT snum FROM shipments WHERE quantity >= 100)"
                                );
                                result.append("<p style='color:#FFA500'>Business logic: Updated supplier statuses</p>");
                            }
                        }
                    }
                } else {
                    result.append("<p style='color:#FF6347'>Error: No SQL command provided</p>");
                }
            }
        } catch (ClassNotFoundException e) {
            result.append("<p style='color:#FF6347'>System error: JDBC driver not found</p>");
            e.printStackTrace();
        } catch (SQLException e) {
            result.append("<p style='color:#FF6347'>SQL Error: ").append(e.getMessage()).append("</p>");
            System.err.println("SQL ERROR: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            result.append("<p style='color:#FF6347'>System error: ").append(e.getMessage()).append("</p>");
            e.printStackTrace();
        }
        
        request.setAttribute("result", result.toString());
        request.getRequestDispatcher("rootHome.jsp").forward(request, response);
    }
}